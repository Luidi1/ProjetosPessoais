// jest.config.cjs
module.exports = {
    transform: {
      '^.+\\.[tj]sx?$': 'babel-jest'
    },
    // Se precisar, defina o ambiente:
    testEnvironment: 'node'
};
  